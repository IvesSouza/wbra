const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Inicializa o aplicativo Express
const app = express();
app.use(express.json());

// Diretório onde os arquivos serão salvos
const baseDownloadDirectory  = path.join(__dirname, 'downloads');

// Função para baixar uma imagem e salvá-la no diretório especificado
const downloadImage = async (url, baseDownloadDirectory) => {
    try {
        // Obter o nome do arquivo da URL
        const fileName = path.basename(url);

        // Criar um diretório base usando a data/hora atual
        const date = new Date();
        const formattedDate = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
        const formattedTime = `${date.getHours().toString().padStart(2, '0')}-${date.getMinutes().toString().padStart(2, '0')}-${date.getSeconds().toString().padStart(2, '0')}`;
        const uniqueFolderName = `${formattedDate}_${formattedTime}`;

        const downloadDirectory = path.join(baseDownloadDirectory, uniqueFolderName);
        const filePath = path.join(downloadDirectory, fileName);

        // Fazer a requisição HTTP para obter a imagem
        const response = await axios({
            url,
            method: 'GET',
            responseType: 'stream',
        });

        // Criar o diretório se ele não existir
        if (!fs.existsSync(downloadDirectory)) {
            fs.mkdirSync(downloadDirectory, { recursive: true });
        }

        // Criar um write stream para salvar a imagem
        const writer = fs.createWriteStream(filePath);

        // Pipe do stream de resposta para o stream de escrita
        response.data.pipe(writer);

        return new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
    } catch (error) {
        console.error(`Erro ao baixar a imagem de ${url}`, error.message);
    }
};

// Cria uma rota POST para receber os arquivos
app.post('/uploadragency', (req, res) => {

    if (!req.body) {
        res.status(400).send('URLS não existente');
        return false;
    }

    if (req.query.auth != "50678bb62a9640a714218148b097317a"){
        res.status(403).send('Acesso Negado');
        return false;
    }


    console.log('Body Existe')
    let dados = req.body.data
    const urlsArray = dados.split(', ').map(url => url.trim());

    // Função principal para baixar todas as imagens
    const downloadAllImages = async () => {
        const downloadPromises = urlsArray.map(url => downloadImage(url, baseDownloadDirectory));
        await Promise.all(downloadPromises);
        console.log('Todas as imagens foram baixadas com sucesso.');
    };

    downloadAllImages();

    res.status(200).send('Arquivo enviado e salvo com sucesso.');
});

// Inicia o servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
